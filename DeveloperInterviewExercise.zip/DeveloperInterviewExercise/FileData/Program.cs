﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            FileDetails obj = new FileDetails();

            Console.WriteLine(obj.GetData("-v", "-o"));
            Console.WriteLine(obj.GetData("-s", "-o"));

            Console.ReadLine();

        }
    }
}
