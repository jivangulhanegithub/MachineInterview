﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using NUnit.Framework;
using ThirdPartyTools;


namespace RunUnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            FileDetails obj = new FileDetails();

            string result = obj.GetData("-v", "-o");
            string result1 = obj.GetData("-s", "-o");


            NUnit.Framework.Assert.That(Convert.ToInt32(result1), Is.EqualTo(obj._size));
            //NUnit.Framework.Assert.That(Convert.ToDouble(result), Is.EqualTo(Convert.ToDouble(obj._version)));

        }
    }
}
