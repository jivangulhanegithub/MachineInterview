﻿using System;

namespace ThirdPartyTools
{
    public class FileDetails
    {
        public string _version;
        public int _size;

        private readonly Random _random = new Random();

        public string Version(string filePath)
        {
            return _version= string.Format("{0}.{1}.{2}", _random.Next(5), _random.Next(8), _random.Next(22));
        }

        public int Size(string filePath)
        {
            return _size= _random.Next(100000) + 1000000;
        }


        public string GetData(string s1, string s2)
        {

            string outPut = "";
            try
            {
                if (s1 == "-v"|| s1 == "-v" || s1 == "--v" || s1 == "/v" || s1 == "--version" )
                {

                    outPut= Version(s2);
                }
                else
                {
                    if (s1 == "-s" || s1 == "--s" ||  s1 == "/s" || s1 == "--size")
                    {

                        outPut = Size(s2).ToString();

                    }

                }
               

            }
            catch (Exception ex)
            {
                outPut = ex.Message;                
            }

            return outPut;

        }


    }
}
